.onAttach = function(...) {
  trace(library, at=1, quote(try(print(utilbox::caller_info()))))
}