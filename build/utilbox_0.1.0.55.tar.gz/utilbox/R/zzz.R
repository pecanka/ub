.onAttach = function(...) {
  trace(library, at=1, quote(print(utilbox::caller_info())))
}