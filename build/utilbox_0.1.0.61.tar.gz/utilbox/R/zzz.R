.onAttach = function(libname, pkgname) {

}

.onDetach = function(libpath) {

}

.onUnload = function(libpath) {

}
